package com.snhu.sslserver;

import org.apache.tomcat.util.buf.HexUtils;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@SpringBootApplication
public class SslServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }
}

@RestController
class ServerController {

    private static final String HASH_ALGORITHM = "SHA-256";
    private static final String DEFAULT_DATA = "Hello Im juan :D"; // Unique data string with my name on it 

    @RequestMapping("/hash")
    public String generateHash() throws NoSuchAlgorithmException {
        String checksum = generateChecksum(DEFAULT_DATA); // Generate checksum for the default data
        return formatResponse(DEFAULT_DATA, checksum); // Return formatted response
    }

    // Generate checksum for given data
    private String generateChecksum(String data) throws NoSuchAlgorithmException {
        MessageDigest msgDigest = MessageDigest.getInstance(HASH_ALGORITHM); // Use SHA-256
        byte[] byteArr = msgDigest.digest(data.getBytes()); // Generate hash as byte array
        return HexUtils.toHexString(byteArr); // Convert byte array to hex string
    }

    // Format response with data and checksum
    private String formatResponse(String data, String checksum) {
        return "<p>data: " + data + "</p>" +
               "<p>checksum: " + checksum + "</p>";
    }
}
